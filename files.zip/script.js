'use strict';
/* ===== Config: edit these to change the countdown (local time, ISO format) ===== */
const DIWALI_DATES = ['2026-11-08T18:00', '2027-10-29T18:00']; // defaults, not officially verified
const $ = (s) => document.querySelector(s);
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
const store = {
  get(k, d) { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* storage unavailable */ } }
};

/* ===== Intro (shown once per session, skippable, auto-ends) ===== */
const intro = $('#intro');
const endIntro = () => { intro.classList.add('off'); try { sessionStorage.setItem('seen', '1'); } catch {} };
try { if (sessionStorage.getItem('seen') || reduce) intro.classList.add('off'); } catch {}
$('#skip').onclick = endIntro; setTimeout(endIntro, 3500);

/* ===== Nav: solid on scroll, active link, hamburger ===== */
const nav = $('#nav'), menu = $('#menu'), burger = $('#burger');
addEventListener('scroll', () => nav.classList.toggle('solid', scrollY > 40), { passive: true });
burger.onclick = () => { const o = menu.classList.toggle('open'); burger.setAttribute('aria-expanded', o); };
menu.addEventListener('click', (e) => { if (e.target.tagName === 'A') { menu.classList.remove('open'); burger.setAttribute('aria-expanded', false); } });
const links = [...menu.querySelectorAll('a:not(.btn)')];
const spy = new IntersectionObserver((es) => es.forEach((e) => {
  if (e.isIntersecting) links.forEach((l) => l.classList.toggle('active', l.hash === '#' + e.target.id));
}), { threshold: 0.5 });
['home', 'experience', 'greeting', 'traditions'].forEach((id) => spy.observe($('#' + id)));
$('#top').onclick = () => scrollTo({ top: 0 });
$('#yr').textContent = new Date().getFullYear();

/* ===== Hero sparks (light, pauses when tab hidden) ===== */
(() => {
  const c = $('#sparks'), x = c.getContext('2d'); let w, h, ps = [], run = !reduce;
  const size = () => { w = c.width = c.offsetWidth; h = c.height = c.offsetHeight; };
  size(); addEventListener('resize', size);
  for (let i = 0; i < 45; i++) ps.push({ x: Math.random() * w, y: Math.random() * h, r: Math.random() * 1.8 + .4, v: Math.random() * .4 + .15 });
  (function tick() {
    if (run) {
      x.clearRect(0, 0, w, h); x.fillStyle = 'rgba(245,199,107,.8)';
      ps.forEach((p) => { p.y -= p.v; if (p.y < 0) { p.y = h; p.x = Math.random() * w; } x.beginPath(); x.arc(p.x, p.y, p.r, 0, 6.3); x.fill(); });
    }
    requestAnimationFrame(tick);
  })();
  document.addEventListener('visibilitychange', () => { run = !document.hidden && !reduce; });
})();

/* ===== Diyas ===== */
const diyaWrap = $('#diyas'), diyas = [];
for (let i = 0; i < 9; i++) {
  const b = document.createElement('button');
  b.className = 'diya'; b.setAttribute('aria-pressed', 'false'); b.setAttribute('aria-label', `Diya ${i + 1}`);
  b.innerHTML = '<svg viewBox="0 0 120 90" aria-hidden="true"><use href="#diya"/></svg>';
  b.onclick = () => setDiya(b, !b.classList.contains('lit'), true);
  diyaWrap.append(b); diyas.push(b);
}
function setDiya(b, on, burst) {
  b.classList.toggle('lit', on); b.setAttribute('aria-pressed', on);
  if (on && burst) { const r = b.getBoundingClientRect(); fwBurst(r.left + r.width / 2, r.top, 18, true); }
  const n = diyas.filter((d) => d.classList.contains('lit')).length;
  $('#count').textContent = `You have lit ${n} diya${n === 1 ? '' : 's'}.`;
}
$('#lightAll').onclick = () => diyas.forEach((d) => setDiya(d, true, false));
$('#resetDiyas').onclick = () => diyas.forEach((d) => setDiya(d, false, false));

/* ===== Rangoli (SVG built from data, so each palette/pattern is a redraw) ===== */
const palettes = {
  Festive: ['#FF9A35', '#E7A59B', '#F5C76B', '#571B30'],
  Royal: ['#F5C76B', '#8b5cf6', '#211039', '#FFF5E6'],
  Emerald: ['#34d399', '#F5C76B', '#0f766e', '#E7A59B']
};
let pal = 'Festive';
const NS = 'http://www.w3.org/2000/svg';
const mk = (t, a) => { const e = document.createElementNS(NS, t); for (const k in a) e.setAttribute(k, a[k]); return e; };
function drawRangoli() {
  const n = +$('#rgPattern').value, [a, b, c, d] = palettes[pal], P = $('#rg-petals'), O = $('#rg-outer');
  P.replaceChildren(); O.replaceChildren();
  for (let i = 0; i < n; i++) {
    const ang = (360 / n) * i;
    P.append(mk('path', { d: 'M0 -24 C14 -50 14 -70 0 -90 C-14 -70 -14 -50 0 -24Z', fill: i % 2 ? b : a, stroke: d, 'stroke-width': 1, transform: `rotate(${ang})` }));
    O.append(mk('circle', { cx: 0, cy: -95, r: 3, fill: c, transform: `rotate(${ang + 180 / n})` }));
  }
  O.append(mk('circle', { r: 30, fill: 'none', stroke: c, 'stroke-width': 2, 'stroke-dasharray': '2 4' }));
  $('#rg-core').setAttribute('fill', d);
}
$('#rg').insertAdjacentHTML('beforebegin', '');
const swRow = document.querySelector('#rangoli [role=group]');
Object.keys(palettes).forEach((name) => {
  const s = document.createElement('button');
  s.className = 'sw'; s.setAttribute('aria-label', name + ' palette'); s.setAttribute('aria-pressed', name === pal);
  s.style.background = `linear-gradient(135deg,${palettes[name][0]} 50%,${palettes[name][1]} 50%)`;
  s.onclick = () => { pal = name; swRow.querySelectorAll('.sw').forEach((x) => x.setAttribute('aria-pressed', x === s)); drawRangoli(); };
  swRow.append(s);
});
$('#rgPattern').onchange = drawRangoli;
$('#rgDiya').onclick = (e) => { const on = $('#rg-diya').style.display === 'none'; $('#rg-diya').style.display = on ? '' : 'none'; e.target.setAttribute('aria-pressed', on); };
$('#rgReset').onclick = () => { pal = 'Festive'; $('#rgPattern').value = '8'; $('#rg-diya').style.display = 'none'; swRow.querySelectorAll('.sw').forEach((x, i) => x.setAttribute('aria-pressed', i === 0)); drawRangoli(); };
drawRangoli();

/* ===== Greeting generator (plain text only, via textContent) ===== */
const T = {
  English: {
    open: (r) => `Happy Diwali, ${r}!`, close: 'With love,', cl2: 'With best wishes,',
    body: {
      Heartfelt: 'May your home glow with happiness, your heart overflow with peace, and your life shine with success. Wishing you and your loved ones a beautiful festival of lights.',
      Traditional: 'May Goddess Lakshmi bless you and your family with prosperity, health and joy this Deepavali.',
      Friendly: 'Hope your Diwali is full of sweets, laughter, lights and great company. Enjoy every moment!',
      Professional: 'Wishing you and your team a bright and prosperous Diwali, and a year of success ahead.'
    }
  },
  Hindi: {
    open: (r) => `प्रिय ${r},`, close: 'सप्रेम,', cl2: 'सादर,',
    body: {
      Heartfelt: 'आपको और आपके पूरे परिवार को दीपावली की हार्दिक शुभकामनाएँ। यह त्योहार आपके जीवन में सुख, शांति, समृद्धि और ढेर सारी खुशियाँ लेकर आए।',
      Traditional: 'माँ लक्ष्मी की कृपा आप पर और आपके परिवार पर सदा बनी रहे। दीपावली की मंगलमय शुभकामनाएँ।',
      Friendly: 'मिठाइयों, हँसी और रोशनी से भरी दीपावली मनाइए। शुभ दीपावली!',
      Professional: 'आपको और आपकी टीम को दीपावली की हार्दिक शुभकामनाएँ। आगामी वर्ष सफलता से भरा रहे।'
    }
  },
  Hinglish: {
    open: (r) => `Happy Diwali, ${r}!`, close: 'With best wishes,', cl2: 'Warm regards,',
    body: {
      Heartfelt: 'Aapki life khushiyon se roshan rahe, har sapna poora ho, aur aapke ghar mein hamesha pyaar aur prosperity bani rahe.',
      Traditional: 'Maa Lakshmi ki kripa aap aur aapke parivaar par hamesha bani rahe. Deepavali ki bahut shubhkamnayein.',
      Friendly: 'Khoob saari mithai, masti aur roshni wali Diwali ho! Enjoy karo!',
      Professional: 'Aapko aur aapki team ko Diwali ki hardik shubhkamnayein. Naya saal success se bhara ho.'
    }
  }
};
const card = $('#card'); let lastText = '';
const say = (m) => { $('#gStatus').textContent = m; };
$('#gform').addEventListener('submit', (e) => {
  e.preventDefault();
  const from = $('#gFrom').value.trim(), to = $('#gTo').value.trim();
  if (!from || !to) { $('#gErr').textContent = 'Please enter both your name and the recipient\'s name.'; return; }
  $('#gErr').textContent = '';
  const t = T[$('#gLang').value], st = $('#gStyle').value, extra = $('#gMsg').value.trim();
  const closing = st === 'Professional' ? t.cl2 : t.close;
  lastText = [t.open(to), '', t.body[st], extra && '\n' + extra, '', closing, from].filter((l) => l !== '' || true).filter((l) => l !== false && l !== undefined && l !== null && l !== '' || l === '').join('\n').replace(/\n{3,}/g, '\n\n');
  card.className = 'card ' + $('#gTheme').value; card.textContent = lastText;
  say('Greeting ready. You can copy, share or print it.');
});
async function copyText(t) {
  try { await navigator.clipboard.writeText(t); return true; } catch {
    const ta = document.createElement('textarea'); ta.value = t; document.body.append(ta); ta.select();
    let ok = false; try { ok = document.execCommand('copy'); } catch {} ta.remove(); return ok;
  }
}
$('#gCopy').onclick = async () => { if (!lastText) return say('Create a greeting first.'); say((await copyText(lastText)) ? 'Copied to clipboard.' : 'Copy failed. Select the card text and copy it manually.'); };
$('#gShare').onclick = async () => {
  if (!lastText) return say('Create a greeting first.');
  if (navigator.share) { try { await navigator.share({ title: 'Diwali greeting', text: lastText }); say('Shared.'); } catch { say('Sharing was cancelled.'); } }
  else say((await copyText(lastText)) ? 'Sharing is not supported here, so the greeting was copied. Paste it into any app to send.' : 'Sharing is not supported. Select the card text and copy it manually.');
};
$('#gPrint').onclick = () => { if (!lastText) return say('Create a greeting first.'); print(); };
$('#gReset').onclick = () => { $('#gform').reset(); lastText = ''; card.className = 'card gold'; card.innerHTML = '<p class="hint">Your greeting appears here.</p>'; $('#gErr').textContent = ''; say('Cleared. Create another greeting.'); };

/* ===== Fireworks: bounded particles; the loop runs only while particles exist ===== */
const fc = $('#fw'), fx = fc.getContext('2d'), MAX = 500; let parts = [], looping = false, W = 0, H = 0, dpr = 1;
const colors = ['#F5C76B', '#FF9A35', '#E7A59B', '#a78bfa', '#34d399'];
function fit() { dpr = devicePixelRatio || 1; W = fc.clientWidth; H = fc.clientHeight; fc.width = W * dpr; fc.height = H * dpr; fx.setTransform(dpr, 0, 0, dpr, 0, 0); }
fit(); addEventListener('resize', fit);
function fwBurst(px, py, n = 60, page = false) {
  if (reduce && !page) n = 15;
  if (page) { const r = fc.getBoundingClientRect(); px -= r.left; py -= r.top; if (px < 0 || py < 0 || px > W || py > H) return; }
  const col = colors[Math.random() * colors.length | 0];
  for (let i = 0; i < n && parts.length < MAX; i++) {
    const a = Math.random() * 6.283, s = Math.random() * 4 + 1;
    parts.push({ x: px, y: py, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: 1, d: Math.random() * .015 + .01, c: Math.random() < .7 ? col : colors[Math.random() * 5 | 0] });
  }
  if (!looping) { looping = true; requestAnimationFrame(frame); }
}
function frame() {
  if (document.hidden) { looping = parts.length > 0 && false; parts = []; fx.clearRect(0, 0, W, H); return; }
  fx.fillStyle = 'rgba(4,5,14,.2)'; fx.fillRect(0, 0, W, H); // fading trails
  parts = parts.filter((p) => p.life > 0);
  parts.forEach((p) => { p.x += p.vx; p.y += p.vy; p.vy += .04; p.vx *= .985; p.life -= p.d; fx.globalAlpha = Math.max(p.life, 0); fx.fillStyle = p.c; fx.fillRect(p.x, p.y, 2.2, 2.2); });
  fx.globalAlpha = 1;
  if (parts.length) requestAnimationFrame(frame); else { looping = false; fx.clearRect(0, 0, W, H); }
}
fc.addEventListener('pointerdown', (e) => { const r = fc.getBoundingClientRect(); fwBurst(e.clientX - r.left, e.clientY - r.top); });
$('#fwGo').onclick = () => { for (let i = 0; i < 5; i++) setTimeout(() => fwBurst(W * (.15 + Math.random() * .7), H * (.15 + Math.random() * .4)), i * 350); };
$('#fwClear').onclick = () => { parts = []; fx.clearRect(0, 0, W, H); };

/* ===== Countdown (visitor's local time) ===== */
const cdIn = $('#cdInput'), pad = (n) => String(n).padStart(2, '0');
let target = store.get('target', null) || DIWALI_DATES.map((d) => new Date(d)).find((d) => d > Date.now()) || null;
if (typeof target === 'string') target = new Date(target);
const toLocalInput = (d) => new Date(d - d.getTimezoneOffset() * 6e4).toISOString().slice(0, 16);
if (target) cdIn.value = toLocalInput(target);
cdIn.onchange = () => { const d = new Date(cdIn.value); if (!isNaN(d)) { target = d; store.set('target', d.toISOString()); tickCd(); } };
function tickCd() {
  const el = $('#cd'); let ms = target ? target - Date.now() : -1;
  if (ms <= 0) {
    const next = DIWALI_DATES.map((d) => new Date(d)).find((d) => d > Date.now());
    el.textContent = 'Diwali has arrived. Shubh Deepavali!';
    $('#cdNote').textContent = next ? 'Next configured date: ' + next.toLocaleString() + '. Pick it above to count down.' : 'Choose a new date above to start another countdown.';
    return;
  }
  const v = [['days', ms / 864e5 | 0], ['hours', ms / 36e5 % 24 | 0], ['minutes', ms / 6e4 % 60 | 0], ['seconds', ms / 1e3 % 60 | 0]];
  el.replaceChildren(...v.map(([l, n]) => { const s = document.createElement('span'); s.textContent = pad(n); const sm = document.createElement('small'); sm.textContent = l; s.append(sm); return s; }));
  $('#cdNote').textContent = 'Counting down to ' + target.toLocaleString() + ' (your local time).';
}
tickCd(); setInterval(tickCd, 1000);

/* ===== Wish wall (localStorage, text only) ===== */
let wishes = store.get('wishes', []);
const wallEl = $('#wishes');
function renderWishes() {
  wallEl.replaceChildren();
  if (!wishes.length) { const p = document.createElement('p'); p.className = 'sub'; p.textContent = 'No wishes yet. Be the first to post one.'; wallEl.append(p); return; }
  wishes.forEach((w) => {
    const d = document.createElement('article'); d.className = 'w';
    const p = document.createElement('p'); p.textContent = '“' + w.text + '”';
    const n = document.createElement('strong'); n.textContent = '— ' + w.name;
    const b = document.createElement('button'); b.textContent = 'Remove'; b.setAttribute('aria-label', 'Remove wish from ' + w.name);
    b.onclick = () => { wishes = wishes.filter((x) => x.id !== w.id); store.set('wishes', wishes); renderWishes(); };
    d.append(p, n, document.createElement('br'), b); wallEl.append(d);
  });
}
$('#wform').addEventListener('submit', (e) => {
  e.preventDefault();
  const name = $('#wName').value.trim(), text = $('#wText').value.trim();
  if (!name || text.length < 3) { $('#wErr').textContent = 'Enter a name and a wish of at least 3 characters.'; return; }
  $('#wErr').textContent = '';
  wishes = [{ id: Date.now(), name, text }, ...wishes].slice(0, 30); store.set('wishes', wishes);
  $('#wform').reset(); renderWishes();
});
renderWishes();

/* ===== Quotes ===== */
const quotes = ['May the light of every diya guide you toward a brighter tomorrow.', 'A little light, a little love, and a thousand reasons to smile.', 'Let kindness be the first lamp you light this year.', 'May every corner of your home glow with peace.', 'One flame shared with a neighbour makes the whole street brighter.'];
let qi = 0; const q = $('#q'); q.textContent = quotes[0];
$('#qNext').onclick = () => { q.style.opacity = 0; setTimeout(() => { qi = (qi + 1) % quotes.length; q.textContent = quotes[qi]; q.style.opacity = 1; }, reduce ? 0 : 500); };
