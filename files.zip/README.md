# Deepotsav — Light Up Someone's World

A single-page Diwali celebration site: hero, interactive diyas, rangoli studio, greeting card builder, fireworks canvas, countdown, traditions, a local wish wall and rotating blessings. Plain HTML, CSS and JavaScript. No build step, no backend.

## Structure
```
deepotsav/
├── index.html
├── style.css
├── script.js
├── assets/images/   (empty, for your own images)
└── assets/audio/    (empty, for optional audio)
README.md
```

## Run it
- **VS Code:** install "Live Server", right-click `index.html`, choose "Open with Live Server".
- **No tools:** double-click `index.html` to open it in a browser.

## Configure the countdown
Edit `DIWALI_DATES` at the top of `script.js` (ISO local time). These are defaults, not officially verified dates. Visitors can also pick their own date in the page; it is saved in localStorage.

## Not included yet
Music/sound control, the festive image gallery with lightbox, and hero parallax were left out of this first version. To add audio later, put a royalty-free file in `assets/audio/` and wire an `<audio>` element to a user-initiated button (never autoplay).

## Notes
- Google Fonts load from the web; system serif/sans fonts are used if offline.
- Wishes stay in the current browser only.
- This code was written but not run in a browser by the author, so please test it and report anything broken.
